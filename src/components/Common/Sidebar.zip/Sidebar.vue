<template>
  <div id="web-cover" class="web-covers J_minicart_close">
    <div title="返回顶部" class="cover-top goto-top"></div>
    <a href="/trade/cart" title="购物车" class="cover-cart"></a>
    <a href="javascript:;" title="在线客服" class="cover-kefu"></a>
  </div>
</template>
    
    <script>
export default {
  name: "Sidebar",
};
</script>
    
    <style lang="scss">
@import "../../../scss/Sidebar.scss";
</style>