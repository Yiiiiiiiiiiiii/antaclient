<template>
  <div class="main-ft">
    <div class="main-ft-inner">
      <h3 class="main-ft-title"></h3>
      <p>抢先得知最新产品、独家消息及优惠资讯</p>
      <ul class="main-ft-links">
        <li class="main-ft-weixin">
          <a href="javascript:;"
            ><div class="com-qr-code">
              <img
                src="https://img.fishfay.com/theme/images/antacom/com-qr-code.jpg"
                alt=""
              />
              </div
          ></a>
        </li>
        <li class="main-ft-weibo">
          <a href="#" target="_blank"></a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style lang="scss">
@import "../../../scss/Footer1.scss";
</style>