<template>
  <footer id="mall_footer" class="footer footer-cn w-full J_minicart_close">
    <div class="ft-inner w-1280 clearfix">
      <div class="ft-slogan fl">
        <img
          src="https://img.fishfay.com/theme/images/logo/slogan-anta-r.svg"
          alt=""
          class="loading"
        />
      </div>
      <div class="ft-main fr clearfix">
        <div class=" first fl">
          <h4 class="server-btn">在线客服<span class="server-icon"></span></h4>
          <h4>在线咨询<span class="server-tel">400-858-2020</span></h4>
        </div>
        <div class="custom-service fl">
          <a href="javascript:;" class="weixin-code"></a>
        </div>
        <div class="ft-company fl" style="height: auto">
          <span>Copyright(C) 2012-2020 by www.ANTA.cn</span>
          <span>©安踏体育用品有限公司版权所有</span>
          <a target="_blank" href="/help/60.html">营业执照</a>
          <a target="_blank" href="/help/61.html">开户许可证</a>
          <a target="_blank" href="/cms/statement">个人信息保护政策</a> <br />
          <a target="_blank" href="https://beian.miit.gov.cn/"
            >闽ICP备2021011550号-2</a
          >
          <a
            target="_blank"
            href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=35020302033806"
            >闽公网安备35020302033806号</a
          >
        </div>
      </div>
    </div>
  </footer>
</template>
  
  <script>
export default {
  name: "Footer",
};
</script>
  
  <style lang="scss">
@import "../../../scss/Footer2.scss";
</style>